export default[

    {
        path: "/M2/eng/multiply2/Index",
        name: "eng-multiply2-index",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply2Index.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply2intro",
        name: "eng-multiply2intro",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply2intro.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply2intro1",
        name: "eng-multiply2intro1",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply2intro1.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply201",
        name: "eng-multiply201",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply201.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply202",
        name: "eng-multiply202",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply202.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply203",
        name: "eng-multiply203",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply203.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply204",
        name: "eng-multiply204",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply204.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply205",
        name: "eng-multiply205",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply205.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply2intro2",
        name: "eng-multiply2intro2",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply2intro2.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply206",
        name: "eng-multiply206",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply206.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply207",
        name: "eng-multiply207",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply207.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply208",
        name: "eng-multiply208",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply208.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply209",
        name: "eng-multiply209",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply209.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply210",
        name: "eng-multiply210",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply210.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply211",
        name: "eng-multiply211",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply211.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply212",
        name: "eng-multiply212",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply212.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply213",
        name: "eng-multiply213",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply213.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply214",
        name: "eng-multiply214",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply214.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply215",
        name: "eng-multiply215",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply215.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply2intro34",
        name: "eng-multiply2intro34",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply2intro34.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply216",
        name: "eng-multiply216",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply216.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply217",
        name: "eng-multiply217",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply217.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply218",
        name: "eng-multiply218",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply218.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply219",
        name: "eng-multiply219",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply219.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply220",
        name: "eng-multiply220",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply220.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply221",
        name: "eng-multiply221",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply221.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply222",
        name: "eng-multiply222",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply222.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply223",
        name: "eng-multiply223",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply223.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply224",
        name: "eng-multiply224",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply224.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply225",
        name: "eng-multiply225",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply225.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply2intro5",
        name: "eng-multiply2intro5",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply2intro5.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply226",
        name: "eng-multiply226",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply226.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply227",
        name: "eng-multiply227",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply227.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply228",
        name: "eng-multiply228",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply228.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply229",
        name: "eng-multiply229",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply229.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply230",
        name: "eng-multiply230",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply230.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply231",
        name: "eng-multiply231",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply231.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply232",
        name: "eng-multiply232",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply232.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply233",
        name: "eng-multiply233",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply233.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply234",
        name: "eng-multiply234",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply234.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply235",
        name: "eng-multiply235",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply235.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply236",
        name: "eng-multiply236",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply236.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply237",
        name: "eng-multiply237",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply237.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply238",
        name: "eng-multiply238",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply238.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply239",
        name: "eng-multiply239",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply239.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply240",
        name: "eng-multiply240",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply240.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply241",
        name: "eng-multiply241",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply241.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply242",
        name: "eng-multiply242",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply242.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply243",
        name: "eng-multiply243",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply243.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply244",
        name: "eng-multiply244",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply244.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply245",
        name: "eng-multiply245",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply245.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply246",
        name: "eng-multiply246",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply246.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply247",
        name: "eng-multiply247",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply247.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply248",
        name: "eng-multiply248",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply248.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply249",
        name: "eng-multiply249",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply249.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply250",
        name: "eng-multiply250",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply250.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply251",
        name: "eng-multiply251",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply251.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply2/multiply252",
        name: "eng-multiply252",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply2/EngMultiply252.vue"
          );
        },
    },
];